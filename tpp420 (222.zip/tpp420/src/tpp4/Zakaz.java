package tpp4;

import java.io.Serializable;
import java.text.SimpleDateFormat;

import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ZAKAZ database table.
 * 
 */
@Entity
@NamedQuery(name="Zakaz.findAll", query="SELECT z FROM Zakaz z")
public class Zakaz implements Serializable,IModel {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Temporal(TemporalType.DATE)
	private Date date;

	//bi-directional many-to-one association to Client
	@ManyToOne
	@JoinColumn(name="IDCLIENT")
	private Client client;

	//bi-directional many-to-one association to Product
	@ManyToOne
	@JoinColumn(name="IDPRODUCT")
	private Product product;

	@ManyToOne
	@JoinColumn(name="IDPRODUCT1")
	private Product product1;
	
	@ManyToOne
	@JoinColumn(name="IDPRODUCT2")
	private Product product2;
	
	public Zakaz() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Client getClient() {
		return this.client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public void setProduct2(Product product2) {
		this.product2 = product2;
	}
	
	public Product getProduct2() {
		return this.product2;
	}
	
	public Product getProduct1() {
		return this.product1;
	}
	
	public void setProduct1(Product product1) {
		this.product1 = product1;
	}
	
	/*@Override
	public String toString() {
		return "Zakaz [id=" + id + ", date=" + date + ", client=" + client + ", product=" + product +  "]";
	}*/

	public String[] getTableHeaders() {
		return new String[]{"Id","Date","Client","Product","Product1","Product2" };
	}

	@Override
	public String toString() {
		return "Zakaz [id=" + id + ", date=" + date + ", client=" + client + ", product=" + product + ", product1="
				+ product1 + ", product2=" + product2 + "]";
	}

	public Object[] getTableRowData() {
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
		String s = myFormat.format(date);
		return new Object[]{id,s,client,product,product1,product2};
	}

/*	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((client == null) ? 0 : client.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		return result;
	}*/

	/*@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Zakaz other = (Zakaz) obj;
		if (client == null) {
			if (other.client != null)
				return false;
		} else if (!client.equals(other.client))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		return true;
	}*/

	@Override
	public void updateWith(Object mask) {
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((client == null) ? 0 : client.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + id;
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		result = prime * result + ((product1 == null) ? 0 : product1.hashCode());
		result = prime * result + ((product2 == null) ? 0 : product2.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Zakaz other = (Zakaz) obj;
		if (client == null) {
			if (other.client != null)
				return false;
		} else if (!client.equals(other.client))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (id != other.id)
			return false;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		if (product1 == null) {
			if (other.product1 != null)
				return false;
		} else if (!product1.equals(other.product1))
			return false;
		if (product2 == null) {
			if (other.product2 != null)
				return false;
		} else if (!product2.equals(other.product2))
			return false;
		return true;
	}

}