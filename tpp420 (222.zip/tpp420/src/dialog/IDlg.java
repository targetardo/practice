package dialog;

public interface IDlg {
		Object getObject();
	}

